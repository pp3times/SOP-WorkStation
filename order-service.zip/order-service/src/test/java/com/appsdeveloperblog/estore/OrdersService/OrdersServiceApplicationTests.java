package com.appsdeveloperblog.estore.OrdersService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrdersServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
